ZRF (ZR FLNG) - E3D SETUP PACKAGE (start from zero)
Generated 2026-10-21. Full guide: ZRF-E3D-Register.xlsx, sheet 'Setup Steps'.

PREPARATION (Admin, SYSTEM)
 - Delete all old ZRF DBs. Check MDB-ZRF is empty and no old ZRF DB files remain in the project folder.
 - Nobody else logged in to ZRF.

STEPS (command macros only)
 00-TEAMS -> per discipline: B1 (Admin) -> B2 sites (Design) -> B3 zones (Design)

ORDER: disciplines 01 -> 10 (MDB positions follow on), then 90-REFERENCE.
Admin steps before Design steps; re-enter DESIGN after each Admin step.
99-FIXUP only if the MDB order is wrong.

KNOWN ISSUE: random '(43,41) Unable to open DB ... MCD:6 The handle is invalid' while creating DBs.
Note the DB, delete it in Admin if broken, recreate it, continue.
